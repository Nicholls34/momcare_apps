// ==========================================
// PROJECT NAME: Mom Care App
// VERSION: v15 (Dynamic Blood Pressure Status)
// CHANGES:
// 1. Added dynamic logic to check Blood Pressure (Normal vs Abnormal).
// 2. Maintained all UI, AI, and functions from v14.
// ==========================================

import 'package:flutter/material.dart';
import 'dart:math';
import 'package:google_generative_ai/google_generative_ai.dart';

// ==========================================
// LOCAL MEMORY DATABASE
// ==========================================
class DatabaseMemory {
  static List<Map<String, String>> symptomRecords = [];
  static List<Map<String, String>> weightRecords = [];
  static List<Map<String, String>> bpRecords = [];
  static List<Map<String, String>> hrRecords = [];
  static List<Map<String, dynamic>> reminderList = [];
}

void main() {
  runApp(const MomCareApp());
}

class MomCareApp extends StatelessWidget {
  const MomCareApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mom Care',
      theme: ThemeData(
        scaffoldBackgroundColor: const Color(0xFFF9F9F9),
        primarySwatch: Colors.teal,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      home: const LoginPage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

// ==========================================
// 1. LOGIN / REGISTER PAGE
// ==========================================
class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  bool _isLoginMode = false;
  bool _hidePassword = true;

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      String userName = _nameController.text.isNotEmpty ? _nameController.text : 'Super Mom';
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => CompleteProfilePage(name: userName)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 30.0),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Icon(Icons.child_care, size: 80, color: Colors.teal),
                  const SizedBox(height: 20),
                  Text(_isLoginMode ? 'Login to Mom Care' : 'Join Mom Care', textAlign: TextAlign.center, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.black87)),
                  const SizedBox(height: 40),
                  if (!_isLoginMode) ...[
                    TextFormField(controller: _nameController, decoration: InputDecoration(labelText: 'Nickname', prefixIcon: const Icon(Icons.person_outline), border: OutlineInputBorder(borderRadius: BorderRadius.circular(15.0)), filled: true, fillColor: Colors.grey[50]), validator: (value) => value == null || value.isEmpty ? 'Please enter your name' : null),
                    const SizedBox(height: 20),
                  ],
                  TextFormField(controller: _emailController, keyboardType: TextInputType.emailAddress, decoration: InputDecoration(labelText: 'Email', prefixIcon: const Icon(Icons.email_outlined), border: OutlineInputBorder(borderRadius: BorderRadius.circular(15.0)), filled: true, fillColor: Colors.grey[50])),
                  const SizedBox(height: 20),
                  TextFormField(controller: _passwordController, obscureText: _hidePassword, decoration: InputDecoration(labelText: 'Password', prefixIcon: const Icon(Icons.lock_outline), suffixIcon: IconButton(icon: Icon(_hidePassword ? Icons.visibility_off : Icons.visibility, color: Colors.grey), onPressed: () => setState(() => _hidePassword = !_hidePassword)), border: OutlineInputBorder(borderRadius: BorderRadius.circular(15.0)), filled: true, fillColor: Colors.grey[50])),
                  const SizedBox(height: 30),
                  ElevatedButton(onPressed: _submitForm, style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.0))), child: Text(_isLoginMode ? 'Login' : 'Register & Continue', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
                  const SizedBox(height: 20),
                  TextButton(onPressed: () => setState(() { _isLoginMode = !_isLoginMode; _formKey.currentState?.reset(); }), child: Text(_isLoginMode ? 'Register Now' : 'Already have an account? Login', style: const TextStyle(color: Colors.teal, fontWeight: FontWeight.bold))),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ==========================================
// 2. COMPLETE PROFILE PAGE
// ==========================================
class CompleteProfilePage extends StatefulWidget {
  final String name;
  const CompleteProfilePage({super.key, required this.name});
  @override State<CompleteProfilePage> createState() => _CompleteProfilePageState();
}

class _CompleteProfilePageState extends State<CompleteProfilePage> {
  final _profileKey = GlobalKey<FormState>();
  final TextEditingController _dobController = TextEditingController();
  final TextEditingController _lmpController = TextEditingController();
  String _childCount = 'First Child';
  DateTime? _lmpDate;

  Future<void> _selectDate(BuildContext context, bool isLMP) async {
    final DateTime? date = await showDatePicker(context: context, initialDate: isLMP ? DateTime.now().subtract(const Duration(days: 90)) : DateTime(1995, 1, 1), firstDate: isLMP ? DateTime.now().subtract(const Duration(days: 300)) : DateTime(1970), lastDate: DateTime.now());
    if (date != null) {
      setState(() {
        if (isLMP) { _lmpDate = date; _lmpController.text = "${date.day}/${date.month}/${date.year}"; }
        else { _dobController.text = "${date.day}/${date.month}/${date.year}"; }
      });
    }
  }

  void _saveProfile() {
    if (_profileKey.currentState!.validate() && _lmpDate != null) {
      int weeks = DateTime.now().difference(_lmpDate!).inDays ~/ 7;
      DateTime edd = _lmpDate!.add(const Duration(days: 280));
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => MainScreen(name: widget.name, pregnancyWeek: weeks, edd: edd)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Pregnancy Profile'), backgroundColor: Colors.teal, foregroundColor: Colors.white),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Form(
          key: _profileKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Hi ${widget.name},', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              const Text('Complete your profile for automatic EDD calculation.', style: TextStyle(color: Colors.grey)),
              const SizedBox(height: 30),
              TextFormField(controller: _dobController, readOnly: true, onTap: () => _selectDate(context, false), decoration: const InputDecoration(labelText: 'Mother\'s Date of Birth', border: OutlineInputBorder(), suffixIcon: Icon(Icons.calendar_today, color: Colors.teal)), validator: (val) => val!.isEmpty ? 'Please select a date' : null),
              const SizedBox(height: 15),
              InputDecorator(decoration: const InputDecoration(labelText: 'Which Pregnancy is this?', border: OutlineInputBorder(), contentPadding: EdgeInsets.symmetric(horizontal: 10)), child: DropdownButtonHideUnderline(child: DropdownButton<String>(value: _childCount, isExpanded: true, items: ['First Child', 'Second Child', 'Third Child', 'More than Three'].map((val) => DropdownMenuItem(value: val, child: Text(val))).toList(), onChanged: (val) => setState(() => _childCount = val!)))),
              const SizedBox(height: 15),
              Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.teal.shade50, borderRadius: BorderRadius.circular(10)), child: const Text('LMP (Last Menstrual Period) is the first day of your last period.', style: TextStyle(fontSize: 12, color: Colors.teal))),
              const SizedBox(height: 8),
              TextFormField(controller: _lmpController, readOnly: true, onTap: () => _selectDate(context, true), decoration: const InputDecoration(labelText: 'Last Menstrual Period (LMP)', border: OutlineInputBorder(), suffixIcon: Icon(Icons.calendar_month, color: Colors.teal)), validator: (val) => val!.isEmpty ? 'Please select LMP date' : null),
              const SizedBox(height: 40),
              SizedBox(width: double.infinity, child: ElevatedButton(onPressed: _saveProfile, style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 16)), child: const Text('Save & Start', style: TextStyle(fontSize: 18)))),
            ],
          ),
        ),
      ),
    );
  }
}

// ==========================================
// 3. MAIN SCREEN
// ==========================================
class MainScreen extends StatefulWidget {
  final String name;
  final int pregnancyWeek;
  final DateTime edd;

  const MainScreen({super.key, required this.name, required this.pregnancyWeek, required this.edd});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    final List<Widget> pages = <Widget>[
      DailyStatusPage(name: widget.name, week: widget.pregnancyWeek, edd: widget.edd),
      const ClinicalPage(),
      const ReminderPage(),
      ReportPage(name: widget.name, week: widget.pregnancyWeek, edd: widget.edd),
      const AIChatPage(),
    ];

    return Scaffold(
      body: pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(icon: Icon(Icons.home_outlined), activeIcon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.health_and_safety_outlined), activeIcon: Icon(Icons.health_and_safety), label: 'Clinical'),
          BottomNavigationBarItem(icon: Icon(Icons.calendar_today_outlined), activeIcon: Icon(Icons.calendar_today), label: 'Log'),
          BottomNavigationBarItem(icon: Icon(Icons.receipt_long_outlined), activeIcon: Icon(Icons.receipt_long), label: 'Report'),
          BottomNavigationBarItem(icon: Icon(Icons.chat_bubble_outline), activeIcon: Icon(Icons.chat_bubble), label: 'AI Chat'),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.teal,
        unselectedItemColor: Colors.grey,
        onTap: (index) => setState(() => _selectedIndex = index),
      ),
    );
  }
}

// ==========================================
// 4. DAILY STATUS PAGE
// ==========================================
class DailyStatusPage extends StatefulWidget {
  final String name;
  final int week;
  final DateTime edd;
  const DailyStatusPage({super.key, required this.name, required this.week, required this.edd});

  @override
  State<DailyStatusPage> createState() => _DailyStatusPageState();
}

class _DailyStatusPageState extends State<DailyStatusPage> {
  final _randomizer = Random();

  final List<Map<String, dynamic>> _symptomOptions = [
    {'label': 'OK', 'icon': Icons.sentiment_very_satisfied, 'color': Colors.green},
    {'label': 'Nausea', 'icon': Icons.sick, 'color': Colors.orange},
    {'label': 'Dizzy', 'icon': Icons.sentiment_dissatisfied, 'color': Colors.redAccent},
    {'label': 'Fatigue', 'icon': Icons.battery_alert, 'color': Colors.blueGrey},
    {'label': 'Backache', 'icon': Icons.accessibility_new, 'color': Colors.brown},
    {'label': 'Cramps', 'icon': Icons.airline_seat_legroom_extra, 'color': Colors.purple},
  ];

  final Map<String, List<String>> _adviceBank = {
    'OK': ['Great! Use this positive energy for some light exercise.', 'Awesome. Maintain a balanced diet and drink 8 glasses of water today.'],
    'Nausea': ['Avoid an empty stomach. Try eating dry crackers before getting out of bed.', 'Drink ginger tea or smell fresh lemons.'],
    'Dizzy': ['Please rest immediately. If lying down, lay on your left side.', 'Dizziness might be a sign of low blood sugar. Try a sweet snack.'],
    'Fatigue': ['Your body is working 24/7. Rest up, you deserve it.', 'Take a short nap during the day (20-30 minutes).'],
    'Backache': ['Use a maternity pillow behind your back when sitting.', 'Do some pelvic tilt stretching exercises.'],
    'Cramps': ['Elevate your feet above heart level when resting.', 'Reduce sodium intake and stay hydrated.'],
  };

  void _askAIPassive(String symptom) {
    setState(() => DatabaseMemory.symptomRecords.insert(0, {'date': DateTime.now().toString().substring(0, 16), 'symptom': symptom}));

    showModalBottomSheet(
      context: context, isDismissible: false,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (BuildContext bottomSheetContext) {
        bool isLoading = true;
        String selectedAdvice = "";
        bool hasStartedLoading = false;

        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setModalState) {
            if (!hasStartedLoading) {
              hasStartedLoading = true;
              Future.delayed(const Duration(milliseconds: 800), () {
                List<String> list = _adviceBank[symptom] ?? ['Please get enough rest.'];
                String randomAnswer = list[_randomizer.nextInt(list.length)];
                if (mounted) {
                  setModalState(() {
                    isLoading = false;
                    selectedAdvice = "Based on week ${widget.week}:\n\n$randomAnswer";
                  });
                }
              });
            }

            return Padding(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [Icon(isLoading ? Icons.auto_awesome : Icons.lightbulb, color: isLoading ? Colors.blue : Colors.amber, size: 30), const SizedBox(width: 10), Expanded(child: Text(isLoading ? 'AI is Analyzing...' : 'Smart Tips', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)))]),
                  const SizedBox(height: 20),
                  if (isLoading) const Center(child: Padding(padding: EdgeInsets.all(20.0), child: CircularProgressIndicator(color: Colors.teal)))
                  else Text(selectedAdvice, style: const TextStyle(fontSize: 16, height: 1.5)),
                  const SizedBox(height: 24),
                  if (!isLoading) SizedBox(width: double.infinity, child: ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 12)), onPressed: () => Navigator.pop(context), child: const Text('Close'))),
                ],
              ),
            );
          },
        );
      },
    );
  }

  String _getBabySize(int week) {
    if (week <= 4) return "Size of a poppy seed.";
    if (week <= 8) return "Size of a raspberry.";
    if (week <= 12) return "Size of a lime.";
    if (week <= 20) return "Size of a banana.";
    if (week <= 28) return "Size of an eggplant.";
    if (week <= 36) return "Size of a papaya.";
    return "Size of a small watermelon. Ready to be born!";
  }

  Widget _buildTopHeader() {
    return Container(
      padding: const EdgeInsets.only(top: 60, left: 20, right: 20, bottom: 40),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFFE0F2F1), Color(0xFFB2EBF2)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30), bottomRight: Radius.circular(30)),
      ),
      child: Row(
        children: [
          const CircleAvatar(radius: 35, backgroundColor: Colors.white, child: Icon(Icons.person, size: 40, color: Colors.teal)),
          const SizedBox(width: 15),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(widget.name, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.black87)),
              Text('Week ${widget.week}', style: const TextStyle(fontSize: 16, color: Colors.black54)),
            ],
          ),
          const Spacer(),
          IconButton(icon: const Icon(Icons.notifications_none, size: 30, color: Colors.black54), onPressed: (){})
        ],
      ),
    );
  }

  Widget _buildProgressCard() {
    int month = (widget.week ~/ 4.3).clamp(1, 9);
    double progress = (widget.week / 40.0).clamp(0.0, 1.0);

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      elevation: 3,
      shadowColor: Colors.black12,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Row(
              children: [
                Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: Colors.orange.shade50, shape: BoxShape.circle), child: const Icon(Icons.child_care, color: Colors.orange)),
                const SizedBox(width: 12),
                const Text('Pregnancy Progress', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                const Spacer(),
                Text('$month months', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.black54)),
              ],
            ),
            const SizedBox(height: 15),
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: LinearProgressIndicator(
                value: progress,
                minHeight: 10,
                backgroundColor: Colors.grey.shade200,
                color: Colors.teal.shade300,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHealthTile(IconData icon, Color iconColor, String title, String value, String subtitle, Widget? trailing) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12.0),
      child: Row(
        children: [
          Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: iconColor.withAlpha(30), borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: iconColor, size: 24)),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.baseline,
                  textBaseline: TextBaseline.alphabetic,
                  children: [
                    Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                    const SizedBox(width: 5),
                    Text(subtitle, style: const TextStyle(fontSize: 12, color: Colors.grey)),
                  ],
                ),
              ],
            ),
          ),
          if (trailing != null) trailing,
        ],
      ),
    );
  }

  // LOGIK STATUS TEKANAN DARAH DINAMIK (DITAMBAH DALAM V15)
  Widget _buildHealthReportCard() {
    String latestWeight = DatabaseMemory.weightRecords.isNotEmpty ? DatabaseMemory.weightRecords[0]['weight']!.replaceAll(' kg', '') : '--';
    String latestBP = DatabaseMemory.bpRecords.isNotEmpty ? DatabaseMemory.bpRecords[0]['bp']! : '--/--';
    String latestHR = DatabaseMemory.hrRecords.isNotEmpty ? DatabaseMemory.hrRecords[0]['hr']! : '--';

    String bpStatusText = '';
    Color bpStatusColor = Colors.transparent;
    Color bpBgColor = Colors.transparent;

    // Membaca dan menentukan status Normal / Abnormal
    if (latestBP != '--/--') {
      try {
        List<String> parts = latestBP.split('/');
        int sys = int.parse(parts[0]);
        int dia = int.parse(parts[1]);

        // Julat Normal Tekanan Darah: Sistolik (90-129) & Diastolik (60-84)
        if (sys >= 90 && sys <= 129 && dia >= 60 && dia <= 84) {
          bpStatusText = 'Normal';
          bpStatusColor = Colors.green;
          bpBgColor = Colors.green.shade50;
        } else {
          bpStatusText = 'Abnormal';
          bpStatusColor = Colors.red;
          bpBgColor = Colors.red.shade50;
        }
      } catch (e) {
        bpStatusText = 'Error';
        bpStatusColor = Colors.orange;
        bpBgColor = Colors.orange.shade50;
      }
    }

    Widget bpTrailing = latestBP != '--/--'
        ? Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(color: bpBgColor, borderRadius: BorderRadius.circular(8)),
        child: Text(bpStatusText, style: TextStyle(color: bpStatusColor, fontWeight: FontWeight.bold, fontSize: 12))
    )
        : const SizedBox.shrink();

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      elevation: 3,
      shadowColor: Colors.black12,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(children: [Icon(Icons.assignment_turned_in, color: Colors.teal), SizedBox(width: 8), Text('Health Report', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18))]),
            const SizedBox(height: 10),
            _buildHealthTile(Icons.monitor_weight, Colors.blue, 'Weight', latestWeight, 'kg', const Icon(Icons.chevron_right, color: Colors.grey)),
            const Divider(height: 1, color: Colors.black12),
            _buildHealthTile(Icons.water_drop, Colors.redAccent, 'Blood Pressure', latestBP, 'mmHg', bpTrailing),
            const Divider(height: 1, color: Colors.black12),
            _buildHealthTile(Icons.favorite, Colors.pinkAccent, 'Baby Heart Rate', latestHR, 'bpm', const Icon(Icons.chevron_right, color: Colors.grey)),
          ],
        ),
      ),
    );
  }

  Widget _buildAppointmentCard() {
    Map<String, dynamic>? nextAppt;
    if (DatabaseMemory.reminderList.isNotEmpty) {
      nextAppt = DatabaseMemory.reminderList.firstWhere((element) => element['type'] == 'Clinic Appointment', orElse: () => {});
    }

    String apptText = (nextAppt?.isNotEmpty == true) ? "${nextAppt!['details']}, ${nextAppt['date']}, ${nextAppt['time']}" : "No upcoming appointments";

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      elevation: 3,
      shadowColor: Colors.black12,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(children: [Icon(Icons.calendar_month, color: Colors.teal), SizedBox(width: 8), Text('Doctor Appointment', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18))]),
            const SizedBox(height: 15),
            const Text('Next:', style: TextStyle(color: Colors.grey, fontSize: 14)),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(child: Text(apptText, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15))),
                Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6), decoration: BoxDecoration(color: Colors.teal.shade50, borderRadius: BorderRadius.circular(20)), child: const Text('Active', style: TextStyle(color: Colors.teal, fontWeight: FontWeight.bold, fontSize: 12))),
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget _buildSymptomTile(String label, IconData icon, Color color) {
    return InkWell(
      onTap: () => _askAIPassive(label),
      borderRadius: BorderRadius.circular(12),
      child: Container(
        width: 105, padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: color.withAlpha(76)), boxShadow: [BoxShadow(color: Colors.grey.withAlpha(25), blurRadius: 3, offset: const Offset(0, 2))]),
        child: Column(children: [Icon(icon, size: 32, color: color), const SizedBox(height: 8), Text(label, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12))]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Stack(
            children: [
              _buildTopHeader(),
              Padding(
                padding: const EdgeInsets.only(top: 130.0),
                child: _buildProgressCard(),
              ),
            ],
          ),
          const SizedBox(height: 20),
          _buildHealthReportCard(),
          const SizedBox(height: 20),
          _buildAppointmentCard(),

          const SizedBox(height: 30),
          const Padding(padding: EdgeInsets.symmetric(horizontal: 20), child: Text('How are you feeling today?', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold))),
          const SizedBox(height: 15),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Wrap(
              spacing: 10, runSpacing: 10, alignment: WrapAlignment.center,
              children: _symptomOptions.map((item) => _buildSymptomTile(item['label'], item['icon'], item['color'])).toList(),
            ),
          ),
          const SizedBox(height: 30),
        ],
      ),
    );
  }
}

// ==========================================
// 5. CLINICAL PAGE
// ==========================================
class ClinicalPage extends StatefulWidget {
  const ClinicalPage({super.key});
  @override State<ClinicalPage> createState() => _ClinicalPageState();
}

class _ClinicalPageState extends State<ClinicalPage> {
  final TextEditingController _weightController = TextEditingController();
  final TextEditingController _bpSysController = TextEditingController();
  final TextEditingController _bpDiaController = TextEditingController();
  final TextEditingController _hrController = TextEditingController();

  void _saveWeight() {
    if (_weightController.text.isNotEmpty) {
      setState(() { DatabaseMemory.weightRecords.insert(0, {'date': DateTime.now().toString().substring(0, 10), 'weight': '${_weightController.text} kg'}); _weightController.clear(); });
      FocusScope.of(context).unfocus();
    }
  }

  void _saveBP() {
    if (_bpSysController.text.isNotEmpty && _bpDiaController.text.isNotEmpty) {
      setState(() { DatabaseMemory.bpRecords.insert(0, {'date': DateTime.now().toString().substring(0, 10), 'bp': '${_bpSysController.text}/${_bpDiaController.text}'}); _bpSysController.clear(); _bpDiaController.clear(); });
      FocusScope.of(context).unfocus();
    }
  }

  void _saveHR() {
    if (_hrController.text.isNotEmpty) {
      setState(() { DatabaseMemory.hrRecords.insert(0, {'date': DateTime.now().toString().substring(0, 10), 'hr': _hrController.text}); _hrController.clear(); });
      FocusScope.of(context).unfocus();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Clinical Records'), backgroundColor: Colors.white, surfaceTintColor: Colors.transparent),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Weight Tracker', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Card(
              color: Colors.white, elevation: 1,
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Row(children: [Expanded(child: TextField(controller: _weightController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Weight (kg)', border: OutlineInputBorder(), prefixIcon: Icon(Icons.monitor_weight)))), const SizedBox(width: 10), ElevatedButton(onPressed: _saveWeight, style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 16)), child: const Text('Save'))]),
              ),
            ),
            const SizedBox(height: 20),

            const Text('Blood Pressure', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Card(
              color: Colors.white, elevation: 1,
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(child: TextField(controller: _bpSysController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Systolic (Top)', border: OutlineInputBorder(), prefixIcon: Icon(Icons.water_drop, color: Colors.redAccent)))),
                        const Padding(padding: EdgeInsets.symmetric(horizontal: 8.0), child: Text('/', style: TextStyle(fontSize: 24))),
                        Expanded(child: TextField(controller: _bpDiaController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Diastolic (Bottom)', border: OutlineInputBorder()))),
                      ],
                    ),
                    const SizedBox(height: 10),
                    SizedBox(width: double.infinity, child: ElevatedButton(onPressed: _saveBP, style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, foregroundColor: Colors.white), child: const Text('Save Blood Pressure')))
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            const Text('Baby Heart Rate', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Card(
              color: Colors.white, elevation: 1,
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Row(children: [Expanded(child: TextField(controller: _hrController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Heart Rate (bpm)', border: OutlineInputBorder(), prefixIcon: Icon(Icons.favorite, color: Colors.pinkAccent)))), const SizedBox(width: 10), ElevatedButton(onPressed: _saveHR, style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 16)), child: const Text('Save'))]),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ==========================================
// 6. REMINDER PAGE
// ==========================================
class ReminderPage extends StatefulWidget {
  const ReminderPage({super.key});
  @override State<ReminderPage> createState() => _ReminderPageState();
}

class _ReminderPageState extends State<ReminderPage> {
  final TextEditingController _textController = TextEditingController();
  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;
  String _frequency = 'Once Only';
  bool _isAppointmentMode = true;

  void _selectDate() async {
    final DateTime? date = await showDatePicker(context: context, initialDate: DateTime.now(), firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 365)));
    if (date != null) setState(() => _selectedDate = date);
  }

  void _selectTime() async {
    final TimeOfDay? time = await showTimePicker(context: context, initialTime: TimeOfDay.now());
    if (time != null) setState(() => _selectedTime = time);
  }

  void _addReminder() {
    if (_textController.text.isEmpty || _selectedDate == null || _selectedTime == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please fill in all details!')));
      return;
    }
    setState(() {
      DatabaseMemory.reminderList.add({
        'type': _isAppointmentMode ? 'Clinic Appointment' : 'Take Medicine',
        'details': _textController.text,
        'date': "${_selectedDate!.day}/${_selectedDate!.month}/${_selectedDate!.year}",
        'time': _selectedTime!.format(context),
        'frequency': _frequency
      });
      _textController.clear(); _selectedDate = null; _selectedTime = null; _frequency = 'Once Only';
    });
    FocusScope.of(context).unfocus();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Reminders & Logs'), backgroundColor: Colors.white, surfaceTintColor: Colors.transparent),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [ChoiceChip(label: const Text('Appointment'), selected: _isAppointmentMode, selectedColor: Colors.teal.withAlpha(76), onSelected: (val) => setState(() => _isAppointmentMode = true)), const SizedBox(width: 10), ChoiceChip(label: const Text('Medicine'), selected: !_isAppointmentMode, selectedColor: Colors.teal.withAlpha(76), onSelected: (val) => setState(() => _isAppointmentMode = false))]),
            const SizedBox(height: 10),
            TextField(controller: _textController, decoration: InputDecoration(labelText: _isAppointmentMode ? 'Clinic/Hospital & Purpose' : 'Medicine Name', border: const OutlineInputBorder())),
            const SizedBox(height: 10),
            Row(
                children: [
                  Expanded(child: OutlinedButton.icon(onPressed: _selectDate, icon: const Icon(Icons.calendar_today), label: Text(_selectedDate == null ? 'Date' : "${_selectedDate!.day}/${_selectedDate!.month}"))),
                  const SizedBox(width: 8),
                  Expanded(child: OutlinedButton.icon(onPressed: _selectTime, icon: const Icon(Icons.access_time), label: Text(_selectedTime == null ? 'Time' : _selectedTime!.format(context)))),
                ]
            ),
            const SizedBox(height: 10),
            InputDecorator(decoration: const InputDecoration(labelText: 'Reminder Frequency', border: OutlineInputBorder(), contentPadding: EdgeInsets.symmetric(horizontal: 10)), child: DropdownButtonHideUnderline(child: DropdownButton<String>(value: _frequency, isExpanded: true, items: ['Once Only', 'Every Day', 'Every Week'].map((label) => DropdownMenuItem(value: label, child: Text(label))).toList(), onChanged: (value) => setState(() => _frequency = value!)))),
            const SizedBox(height: 10),
            SizedBox(width: double.infinity, child: ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 14)), onPressed: _addReminder, child: const Text('Save Reminder'))),
            const SizedBox(height: 20), const Divider(),
            const Text('Active List', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            Expanded(child: ListView.builder(itemCount: DatabaseMemory.reminderList.length, itemBuilder: (context, index) {
              final item = DatabaseMemory.reminderList[index];
              return Card(color: Colors.white, child: ListTile(
                  leading: Icon(item['type'] == 'Take Medicine' ? Icons.medication : Icons.local_hospital, color: Colors.teal),
                  title: Text(item['details']!),
                  subtitle: Text('${item['type']} - ${item['date']} (${item['time']})\nFrequency: ${item['frequency']}'),
                  trailing: IconButton(icon: const Icon(Icons.check_circle_outline, color: Colors.green), onPressed: () => setState(() => DatabaseMemory.reminderList.removeAt(index)))
              ));
            })),
          ],
        ),
      ),
    );
  }
}

// ==========================================
// 7. REPORT PAGE
// ==========================================
class ReportPage extends StatelessWidget {
  final String name;
  final int week;
  final DateTime edd;

  const ReportPage({super.key, required this.name, required this.week, required this.edd});

  @override
  Widget build(BuildContext context) {
    int totalSymptoms = DatabaseMemory.symptomRecords.length;
    String lastSymptom = totalSymptoms > 0 ? DatabaseMemory.symptomRecords[0]['symptom']! : 'No Records';
    String lastWeight = DatabaseMemory.weightRecords.isNotEmpty ? DatabaseMemory.weightRecords[0]['weight']! : 'No Records';

    // Status Tekanan Darah untuk Laporan
    String lastBP = DatabaseMemory.bpRecords.isNotEmpty ? DatabaseMemory.bpRecords[0]['bp']! : 'No Records';
    String bpStatus = '';
    if (lastBP != 'No Records') {
      try {
        List<String> parts = lastBP.split('/');
        int sys = int.parse(parts[0]);
        int dia = int.parse(parts[1]);
        bpStatus = (sys >= 90 && sys <= 129 && dia >= 60 && dia <= 84) ? ' (Normal)' : ' (Abnormal)';
      } catch (e) {
        bpStatus = '';
      }
    }

    String lastHR = DatabaseMemory.hrRecords.isNotEmpty ? DatabaseMemory.hrRecords[0]['hr']! : 'No Records';
    int totalReminders = DatabaseMemory.reminderList.length;

    return Scaffold(
      appBar: AppBar(title: const Text('Summary Report'), backgroundColor: Colors.white, surfaceTintColor: Colors.transparent),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('Health & Activity Report', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const Text('Suitable for doctor\'s reference during checkups.', style: TextStyle(color: Colors.grey)),
            const SizedBox(height: 20),

            Card(color: Colors.white, elevation: 1, child: Padding(padding: const EdgeInsets.all(16.0), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Row(children: [Icon(Icons.person, color: Colors.teal), SizedBox(width: 8), Text('Mother\'s Profile', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16))]), const Divider(), Text('Name: $name', style: const TextStyle(fontSize: 16)), Text('Pregnancy Age: $week Weeks', style: const TextStyle(fontSize: 16)), Text('Expected Delivery: ${edd.day}/${edd.month}/${edd.year}', style: const TextStyle(fontSize: 16))]))),
            const SizedBox(height: 10),
            Card(color: Colors.white, elevation: 1, child: Padding(padding: const EdgeInsets.all(16.0), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Row(children: [Icon(Icons.monitor_heart, color: Colors.redAccent), SizedBox(width: 8), Text('Health Summary', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16))]), const Divider(), Text('Latest Symptom: $lastSymptom', style: const TextStyle(fontSize: 16)), Text('Latest Weight: $lastWeight', style: const TextStyle(fontSize: 16)), Text('Latest BP: $lastBP mmHg$bpStatus', style: const TextStyle(fontSize: 16)), Text('Baby Heart Rate: $lastHR bpm', style: const TextStyle(fontSize: 16))]))),
            const SizedBox(height: 10),
            Card(color: Colors.white, elevation: 1, child: Padding(padding: const EdgeInsets.all(16.0), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Row(children: [Icon(Icons.event_note, color: Colors.blue), SizedBox(width: 8), Text('Activity Management', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16))]), const Divider(), Text('Active Reminders: $totalReminders schedules', style: const TextStyle(fontSize: 16))]))),
            const SizedBox(height: 30),

            ElevatedButton.icon(
              icon: const Icon(Icons.picture_as_pdf),
              label: const Text('Generate PDF Report (Coming Soon)'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 16)),
              onPressed: () { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('PDF export feature will be updated later!'))); },
            )
          ],
        ),
      ),
    );
  }
}

// ==========================================
// 8. AI CHAT PAGE
// ==========================================
class AIChatPage extends StatefulWidget {
  const AIChatPage({super.key});
  @override State<AIChatPage> createState() => _AIChatPageState();
}

class _AIChatPageState extends State<AIChatPage> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  late final GenerativeModel _aiModel;
  late final ChatSession _chatSession;
  bool _isTyping = false;

  final List<Map<String, dynamic>> _messages = [
    {'user': false, 'text': 'Hi! I am the Mom Care AI Assistant. I am ready to answer questions about pregnancy, diet, or symptoms you are experiencing.'}
  ];

  @override
  void initState() {
    super.initState();
    _aiModel = GenerativeModel(
      model: 'gemini-2.5-flash',
      apiKey: 'AQ.Ab8RN6KioOXiWBEWCnPG40WLUj1VeM0KhFxYy4LsiX1TthSF5g',
      systemInstruction: Content.system(
          'You are a Pregnancy AI Assistant named "Mom Care AI". '
              'You are an expert, caring, and very friendly. You are chatting with a pregnant mother. '
              'Mandatory requirement: Answer in natural, polite, and relaxed English. '
              'If asked about health, give brief and comforting advice, but always include '
              'a short reminder at the end for the user to consult a doctor for actual medical confirmation.'
      ),
    );
    _chatSession = _aiModel.startChat();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(_scrollController.position.maxScrollExtent, duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
      }
    });
  }

  Future<void> _sendMessage() async {
    final userText = _messageController.text.trim();
    if (userText.isEmpty) return;

    setState(() { _messages.add({'user': true, 'text': userText}); _isTyping = true; });
    _messageController.clear();
    FocusScope.of(context).unfocus();
    _scrollToBottom();

    try {
      final response = await _chatSession.sendMessage(Content.text(userText));
      final aiText = response.text ?? 'Sorry, I couldn\'t understand that question.';
      setState(() { _messages.add({'user': false, 'text': aiText}); });
    } catch (error) {
      setState(() { _messages.add({'user': false, 'text': 'Error: Please check your internet connection or API Key status.'}); });
    } finally {
      setState(() { _isTyping = false; });
      _scrollToBottom();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mom Care AI'), backgroundColor: Colors.white, surfaceTintColor: Colors.transparent),
      body: Column(
        children: [
          Expanded(
              child: ListView.builder(
                  controller: _scrollController,
                  padding: const EdgeInsets.all(16.0),
                  itemCount: _messages.length,
                  itemBuilder: (context, index) {
                    final isUser = _messages[index]['user'];
                    return Align(
                        alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
                        child: Container(
                            margin: const EdgeInsets.only(bottom: 10.0),
                            padding: const EdgeInsets.all(12.0),
                            decoration: BoxDecoration(color: isUser ? Colors.teal.withAlpha(51) : Colors.white, borderRadius: BorderRadius.circular(15.0), border: Border.all(color: Colors.black12)),
                            child: Text(_messages[index]['text'])
                        )
                    );
                  }
              )
          ),
          if (_isTyping) const Padding(padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0), child: Align(alignment: Alignment.centerLeft, child: Text("Gemini is typing...", style: TextStyle(color: Colors.grey, fontStyle: FontStyle.italic, fontSize: 12)))),
          Container(
              padding: const EdgeInsets.all(8.0), color: Colors.white,
              child: Row(
                  children: [
                    Expanded(child: TextField(controller: _messageController, enabled: !_isTyping, decoration: InputDecoration(hintText: _isTyping ? 'Please wait a moment...' : 'Ask the AI a question...', border: OutlineInputBorder(borderRadius: BorderRadius.circular(20.0)), contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 10.0)))),
                    const SizedBox(width: 8),
                    CircleAvatar(backgroundColor: _isTyping ? Colors.grey : Colors.teal, child: IconButton(icon: const Icon(Icons.send, color: Colors.white), onPressed: _isTyping ? null : _sendMessage))
                  ]
              )
          ),
        ],
      ),
    );
  }
}